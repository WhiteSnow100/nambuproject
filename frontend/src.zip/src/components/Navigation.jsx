// - 말입력/암기/사전/사용자
// - 각 메뉴에 링크
// - 선택메뉴는 칼라/미선택 메뉴에 대해서는 흰색

function Navigation(){
    return <div> </div>
}
